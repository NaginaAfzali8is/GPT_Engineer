from flask import Flask, render_template, redirect, session, send_file, url_for, request
import os
from pathlib import Path
import openai

# Import necessary modules and classes from your CLI application
from gpt_engineer.applications.cli.cli_agent import CliAgent
from gpt_engineer.applications.cli.file_selector import FileSelector
from gpt_engineer.core.ai import AI
from gpt_engineer.core.default.disk_execution_env import DiskExecutionEnv
from gpt_engineer.core.default.disk_memory import DiskMemory
from gpt_engineer.core.default.file_store import FileStore
from gpt_engineer.core.default.paths import PREPROMPTS_PATH, memory_path
from gpt_engineer.core.default.steps import execute_entrypoint, gen_code, improve
from gpt_engineer.core.preprompts_holder import PrepromptsHolder
from gpt_engineer.tools.custom_steps import clarified_gen, lite_gen, self_heal
import zipfile

app = Flask(__name__)  # creates a Flask web app
app.secret_key = 'Nim123??'  # Set a secret key for session management


# def load_env_if_needed():
#     """
#     Load environment variables if the OPENAI_API_KEY is not already set.

#     This function checks if the OPENAI_API_KEY environment variable is set,
#     and if not, it attempts to load it from a .env file in the current working
#     directory. It then sets the openai.api_key for use in the application.
#     """
#     if os.getenv("OPENAI_API_KEY") is None:
#         load_dotenv()
#     if os.getenv("OPENAI_API_KEY") is None:
#         # if there is no .env file, try to load from the current working directory
#         load_dotenv(dotenv_path=os.path.join(os.getcwd(), ".env"))
#     openai.api_key = os.getenv("OPENAI_API_KEY")


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/setup_openai_key', methods=['POST'])
def setup_openai_key():
    if request.method == "POST":
        openai_key = request.form["openai_key"]
        projectName = request.form["project_type"]
        projectDesc = request.form["project_description"]

        session['project_name'] = projectName  # Store the project name in the session
        session['openai_key'] = openai_key  # Store the key in the session
        openai.api_key = openai_key

        # Create the project directory if it doesn't exist
        project_path = f"projects/{projectName}"
        if not os.path.exists(project_path):
            os.makedirs(project_path)

        # Set up the AI and project configuration
        ai = AI(
            model_name="gpt-4-1106-preview",  # Set your desired model
            temperature=0.1,
            azure_endpoint="",  # Set Azure endpoint if applicable
        )

        prompt = projectDesc  # Use project description as prompt

        # Configure functions and paths
        code_gen_fn = gen_code
        execution_fn = execute_entrypoint
        improve_fn = improve

        preprompts_path = PREPROMPTS_PATH
        if not os.path.exists(preprompts_path):
            os.makedirs(preprompts_path)

        preprompts_holder = PrepromptsHolder(preprompts_path)
        memory = DiskMemory(memory_path(project_path))
        execution_env = DiskExecutionEnv()
        agent = CliAgent.with_default_config(
            memory,
            execution_env,
            ai=ai,
            code_gen_fn=code_gen_fn,
            improve_fn=improve_fn,
            process_code_fn=execution_fn,
            preprompts_holder=preprompts_holder,
        )

        store = FileStore(project_path)

        # Generate or improve project
        files_dict = agent.init(prompt)

        # Store files in the project directory
        store.upload(files_dict)

        print("Project created successfully!")

        return redirect(url_for('success'))

    return render_template("index.html")


@app.route('/success')
def success():
    if 'openai_key' in session:
        project_name = session.get('project_name')  # Retrieve project name from session
        project_path = f"projects/{project_name}"
        
        # Create a zip file of the project directory
        zipf = zipfile.ZipFile(f'{project_name}.zip', 'w', zipfile.ZIP_DEFLATED)
        for root, dirs, files in os.walk(project_path):
            for file in files:
                zipf.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), os.path.join(project_path, '..')))
        zipf.close()

        print('OpenAI API key set successfully!')

# Render the success template with necessary data
        return render_template('index.html', success=True, file_name=f'{project_name}.zip', download_url=url_for('download', file_name=f'{project_name}.zip'))

    else:
        return redirect(url_for('index'))

@app.route('/download/<file_name>')
def download(file_name):
    return send_file(file_name, as_attachment=True)


if __name__ == "__main__":
    # Check if the OPENAI_API_KEY is set, if not redirect to the setup page
    print("OpenAI API key is not set. Please set it up.")
    print("Starting the web interface for setup...")
    app.run(debug=True, port=5000)
