pip install --user -r requirements.txt

python main.py &
