from customer import Customer
from account import Account

class Bank:
    def __init__(self):
        self.customers = []
        self.accounts = []

    def add_customer(self, customer):
        self.customers.append(customer)

    def create_account(self, customer_id, initial_deposit):
        account = Account(customer_id, initial_deposit)
        self.accounts.append(account)
        return account