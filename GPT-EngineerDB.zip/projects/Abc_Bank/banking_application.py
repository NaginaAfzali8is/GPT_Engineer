from bank import Bank

class BankingApplication:
    def __init__(self):
        self.bank = Bank()

    def run(self):
        # Placeholder for the application's main loop
        pass