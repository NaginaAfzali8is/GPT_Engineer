from banking_application import BankingApplication

def main():
    app = BankingApplication()
    app.run()

if __name__ == "__main__":
    main()