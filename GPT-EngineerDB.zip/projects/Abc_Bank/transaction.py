from dataclasses import dataclass
from enum import Enum, auto

class TransactionType(Enum):
    DEPOSIT = auto()
    WITHDRAWAL = auto()

@dataclass
class Transaction:
    transaction_type: TransactionType
    account_id: int
    amount: float