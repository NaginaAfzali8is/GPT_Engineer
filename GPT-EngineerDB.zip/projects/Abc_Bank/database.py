class Database:
    def __init__(self):
        self.customers = {}
        self.accounts = {}

    def add_customer(self, customer):
        self.customers[customer.customer_id] = customer

    def add_account(self, account):
        self.accounts[account.account_id] = account

    def get_customer(self, customer_id):
        return self.customers.get(customer_id)

    def get_account(self, account_id):
        return self.accounts.get(account_id)